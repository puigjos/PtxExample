library(testthat)
library(PtxExample)

test_check("PtxExample")

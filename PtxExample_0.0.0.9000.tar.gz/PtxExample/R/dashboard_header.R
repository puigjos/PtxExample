

dashboard_header <- function(){
  shinydashboard::dashboardHeader(
    title = 'PtxGenerator'
  )
}
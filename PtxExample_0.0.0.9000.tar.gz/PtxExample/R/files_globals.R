

EMU_cm <<- 360000
inches <<- 0.393700787

bizdays::create.calendar(name="myCalendar", 
                         weekdays=c('saturday', 'sunday'))


